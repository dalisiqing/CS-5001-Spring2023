import re


class DataAnalysis:

    def __init__(self, file):
        # TODO: set up the necessary instance variables
        pass

    def read_data(self, file_name):
        # TODO: read the data and get the counts
        pass

    # TODO:
    # Implement top_n_lang_freqs()
    # Should take a number N as an argument and return
    # an N-length list of tuples representing languages
    # and their frequencies in the data, ordered from
    # highest frequency to lowest.

    # TODO:
    # Implement top_n_country_tlds_freqs()
    # Should take a number N as an argument and return
    # an N-length list of tuples representing country (2-letter)
    # top-level domain identifiers (e.g. 'jp', 'uk', 'cn', 'ca')
    # and their frequencies as email domains the data, ordered 
    # from highest frequency to lowest.

    # TODO:
    # Implement any other necessary/helpful methods to support
    # the ones above.
