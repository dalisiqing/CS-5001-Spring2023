

class Bench:
    """A class representing a sidelines bench"""
    def __init__(self):
        # TODO: Initialize the bench object with whatever
        # attributes and values it will need
        pass

    def send_to_bench(self, player_name):
        # TODO: Put the player "onto the bench"
        pass

    def get_from_bench(self):
        # TODO: Return the name of the player who has
        # been on the bench longest.
        pass

    # TODO: Write the function that will display the
    # current list of players on the bench

    # TODO: Write any other methods that might be used
    # by the methods above.
