from stack import Stack


class StringProcessor:
    """Class for processing strings"""
    pass
