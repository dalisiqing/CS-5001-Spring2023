import sys
# Import whatever other libraries you need

# G and Y represent text formatting codes for green and
# yellow text output. Variable names are brief so as to
# be unobtrusive when interspersed with text
G = '\x1b[0;30;42m'  # green text
Y = '\x1b[0;30;43m'  # yellow text
N = '\x1b[0m'        # normal text/no highlighting

ALLOWED_GUESSES = 6
WORD_LENGTH = 5


def main(args):
    # TODO: If there is an argument, set that argument to be the word.
    # Otherwise, the word should be randomly selected from valid
    # letters of WORD_LENGTH in the Scrabble words file. (Use a
    # separate function to get the valid words from the
    # Scrabble words files)

    # TODO: Study the following string to underestand how G, Y and N
    # behave for colored text highlights
    print(f"Welcome to {Y}PY{G}WOR{Y}D{G}LE{N}!")

    # TODO: You'll want a list to collect failed guesses. You can use
    # this list to print the guesses each time, and also use
    # the list's length to keep track of how many guesses have
    # been made

    # TODO: You'll probably want a while loop to continue as long
    # as the user's answer is not correct and the guesses are
    # fewer than the allowed number of guesses.

    # TODO: You may want yet another while loop to repeat the prompt
    # in case of invalid guesses

    # TODO: Use a separate function, format_guess, to format
    # the guess with green and yellow highlighting for printing out.
    # That's where you'll compare it to the correct word.

    # TODO: Print out the list of guesses so far with each new guess

    # TODO: Print an appropriate message when the game ends


def format_guess():  # TODO: Add necessary parameters

    # TODO: Implement this function so that it returns
    # the guess string highlighted with green and yellow based
    # on comparing letters with the original word.

    # See assignment instructions for specifics about how
    # letters should be highlighted
    pass


def get_valid_words():  # TODO: Add necessary parameters

    # TODO: Implement this function so that it returns
    # a list of words consisting of only words of the
    # correct length from the Scrabble word list
    pass


main(sys.argv)
