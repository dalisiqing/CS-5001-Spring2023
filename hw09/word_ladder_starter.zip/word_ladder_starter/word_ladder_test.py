from word_ladder import WordLadder


# TODO: Write appropriate unit tests

def test_make_ladder():
    assert False
